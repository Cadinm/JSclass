/*    JavaScript 7th Edition
      Chapter 2
      Project 02-03

      Application to return the shape of a clicked object
      Author: Cadin Marohl
      Date:   9/4/2022

      Filename: project02-03.js
 */

      square.onmouseover = function() {
            let element = document.getElementById("feedback");
            element.innerHTML = "You are hovering over the square!";
      }

      square.onmouseout = function() {
            let element = document.getElementById("feedback");
            element.innerHTML = "";
      }

      circle.onmouseover = function() {
            let element = document.getElementById("feedback");
            element.innerHTML = "You are hovering over the circle!";
      }

      circle.onmouseout = function() {
            let element = document.getElementById("feedback");
            element.innerHTML = "";
      }

      triangle.onmouseover = function() {
            let element = document.getElementById("feedback");
            element.innerHTML = "You are hovering over the triangle!";
      }

      triangle.onmouseout = function() {
            let element = document.getElementById("feedback");
            element.innerHTML = "";
      }

/*    JavaScript 7th Edition
      Chapter 2
      Project 02-02

      Application to test for completed form
      Author: Cadin Marohl
      Date:   9/4/2022

      Filename: project02-02.js
 */

function submitInfo() {
      let name = document.getElementById("name");
      let email = document.getElementById("email");
      let phone = document.getElementById("phone");
      (name.value && email.value && phone.value) ? window.alert("Thank You!") :
      window.alert("Please fill in all fields");
}
let submit = document.getElementById("submit");
submit.addEventListener("click", submitInfo, false);

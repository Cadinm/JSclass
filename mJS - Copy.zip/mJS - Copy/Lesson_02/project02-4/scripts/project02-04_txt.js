/*    JavaScript 7th Edition
      Chapter 2
      Project 02-04

      Application to calculate the cost of a restaurant order plus tax
      Author: Cadin Marohl
      Date:   9/4/2022

      Filename: project02-04.js
 */
   const CHICKEN_PRICE = 10.95
   const HALIBUT_PRICE = 13.95
   const BURGER_PRICE = 9.95
   const SALMON_PRICE = 18.95
   const SALAD_PRICE = 7.95
   const SALES_TAX = 0.07

   document.getElementById("chicken").addEventListener("click", calcTotal, false);
   document.getElementById("halibut").addEventListener("click", calcTotal, false);
   document.getElementById("burger").addEventListener("click", calcTotal, false);
   document.getElementById("salmon").addEventListener("click", calcTotal, false);
   document.getElementById("salad").addEventListener("click", calcTotal, false);

function calcTotal() {
   let cost = 0;
   (chicken.checked) ? (cost += CHICKEN_PRICE) : (cost += 0);
   (halibut.checked) ? (cost += HALIBUT_PRICE) : (cost += 0);
   (burger.checked) ? (cost += BURGER_PRICE) : (cost += 0);
   (salmon.checked) ? (cost += SALMON_PRICE) : (cost += 0);
   (salad.checked) ? (cost += SALAD_PRICE) : (cost += 0);
   let food = document.getElementById("foodTotal");
   food.innerHTML = formatCurrency(cost);
   let tax = cost * SALES_TAX;
   let totalCost = cost + tax;
   let bill = document.getElementById("totalBill");
   bill.innerHTML = formatCurrency(totalCost);
}


// Function to display a numeric value as a text string in the format $##.## 
 function formatCurrency(value) {

    return "$" + value.toFixed(2);
 }

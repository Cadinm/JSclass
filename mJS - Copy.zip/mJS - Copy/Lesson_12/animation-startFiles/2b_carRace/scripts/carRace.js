$(function () {
    $("#start").click(function(){
        let num1 = Math.floor(((Math.random() * 5) + 3) * 1000);
        let num2 = Math.floor(((Math.random() * 5) + 3) * 1000);

        $("#car1").animate({left : "1350px"}, num1); //left number is where it ends, right number is the speed
        $("#car2").animate({left : "1350px"}, num2);
    });
    
    $("#reload").click(function(){
        location.reload();
    });

});
